print(2+2)


# isolated environnement specific for this project to prevent version conflict
import cowsay
cowsay.cow("Hello all")
#| eval: false
#pip install plotly pandas jupyter ipykernel kaleido itables


import cowsay
cowsay.cow("Hello all")
